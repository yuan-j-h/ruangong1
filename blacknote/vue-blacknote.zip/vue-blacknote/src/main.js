
// main.js
import 'D:\\Desktop\\vue-demo\\blacknote\\vue-blacknote\\src\\css\\function.css';  //引入css

import { createApp } from 'vue'
import App from './App.vue'

createApp(App).mount('#app')
